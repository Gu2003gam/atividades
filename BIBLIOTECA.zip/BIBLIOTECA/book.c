#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <ctype.h>
#include "book.h"
#include "autor.h"

typedef struct {
    unsigned short int ID;
    unsigned short int pages;
    unsigned short int year;
    unsigned int amount;

    char *title;
    char *type;
    char *publisher;
    Autor *author;
} Book;

typedef struct {
    unsigned short int pages;
    unsigned short int year;
    unsigned int amount;

    char *title;
    char *type;
    char *publisher;
    Autor *author;
} Temp_book;

static char *read_string(void) {

  size_t capacity = 16;
  size_t size = 0;
  char *text = malloc(capacity);
  if (text == NULL) {return NULL;}
  int c;
  while((c = getchar()) != '\n' && c != EOF) {
    if (size + 1 >= capacity) {
      size_t new_capacity = capacity * 2;
      char *temporary = realloc(text, new_capacity);
      if(temporary == NULL) {free(text); return NULL;}
      text = temporary;
      capacity = new_capacity;
    }
    text[size++] = (char)c;
  }
  if (c == EOF && size == 0) {free(text); return NULL;}
  text[size] = '\0';
  return text;
}

static bool get_book_by_id(const unsigned short int ID){
  FILE *book_file = fopen("book.txt", "r");
  if (book_file == NULL) {return false;}
  char row[256];
  while (fgets(row, sizeof(row), book_file) != NULL) {
    char *token = strtok(row, ";");
    if (token != NULL && strtoul(token, NULL, 10) == ID) {
      fclose(book_file);
      return true;
    }
  }
  fclose(book_file);
  return false;
}

static void book_destroy(Book *book) {
  if (book == NULL) {return;}
  free(book->title);
  free(book->type);
  free(book->publisher);
  free(book->author);
  free(book);
}
static void temp_book_destroy(Temp_book *book) {
  if (book == NULL) {return;}
  free(book->title);
  free(book->type);
  free(book->publisher);
  free(book->author);
  free(book);
}

static void clear_buffer(void) {
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}
static bool validate_id(const unsigned short int *ptr, bool type) {
  if (ptr == NULL) {return false;}
  if (type == true) {
    if (get_book_by_id(*ptr)) {
      printf("Esse ID já existe, por favor, tente novamente \n");
      return false;
    }
    else {
      return true;
    }
  }
  else {
    if (!(get_book_by_id(*ptr))) {
      printf("Esse ID não existe, por favor, tente novamente \n");
      return false;
    }
    else {
      return true;
    }
  }
}

extern short int add_book() {

    Book *book = malloc(sizeof(Book));
    if (book == NULL) {
      free(book);
      return -1;
    }
    book->author = malloc(sizeof(Autor));
    if (book->author == NULL) {
      free(book->author);
      return -1;
    }
    char answer;

    FILE *book_file = fopen("book.txt", "a");
    if (book_file == NULL) {return -1;}

    if (book == NULL) {return 1;}
    printf("ID: ");
    scanf("%hu", &book->ID);
    clear_buffer();
    if (!(validate_id(&book->ID, true))) {
      fclose(book_file);
      book_destroy(book);
      book = NULL;
      return -1;
    }
    
    printf("Título: ");
    book->title = read_string();
    if (book->title == NULL) {
    fclose(book_file);
    book_destroy(book);
    return -1;
  }

    printf("Tipo: ");
    book->type = read_string();
    if (book->type == NULL) {
      fclose(book_file);
      book_destroy(book);
      return -1;
    }

    printf("Editora: ");
    book->publisher = read_string();
    if (book->publisher == NULL) {
      fclose(book_file);
      book_destroy(book); 
      return -1;
    }

    printf("Autor(a): ");
    char *temp_nome = read_string();
    if (temp_nome != NULL) {
      strncpy(book->author->nome, temp_nome, sizeof(book->author->nome) - 1);
      book->author->nome[sizeof(book->author->nome) - 1] = '\0';
      free(temp_nome);
    }
    else {
      fclose(book_file);
      book_destroy(book);
      return -1;
    }

    printf("Digite o ID do(a) autor(a): ");
    scanf("%d", &book->author->id);
    clear_buffer();
    if (existeAutor(book->author->id) == 0) {
      printf("Autor não encontrado, deseja cadastrar? (s / n)\n");
      printf(">>> ");
      scanf(" %c", &answer);
      clear_buffer();
      answer = tolower(answer);
      if (answer == 's') {
        cadastrarAutorComId(book->author->id);
      }
      else if (answer == 'n') {
        fclose(book_file);
        book_destroy(book);
        return -1;
      }
    }
    else {
      incrementarObrasAutor(book->author->id);
    }

    printf("Paginas: ");
    scanf("%hu", &book->pages);
    clear_buffer();

    printf("Ano de Lançamento: ");
    scanf("%hu", &book->year);
    clear_buffer();
      
    printf("Quantidade: ");
    scanf("%u", &book->amount);
    clear_buffer();
    printf("\n");

    fprintf(book_file, "%hu;%s;%s;%s;%s;%d;%hu;%hu;%u\n", book->ID, book->title, book->type,book->publisher,
    book->author->nome,book->author->id, book->pages, book->year, book->amount);
    fclose(book_file);
    book_destroy(book);
    book = NULL;

    return 0;
}
extern short int edit_book() {
    char answer;
    unsigned short int ID;
    Temp_book *temporary_book = malloc(sizeof(Temp_book));
    if (temporary_book == NULL) {
      return -1;
      free(temporary_book);
    }
    temporary_book->author = malloc(sizeof(Autor));
    if (temporary_book->author == NULL) {
      free(temporary_book->author);
      return -1;
    }

    FILE *book_file = fopen("book.txt", "r");
    FILE *temp_file = fopen("temporary.txt", "w");
    if (book_file == NULL || temp_file == NULL) {
      if (book_file != NULL) {fclose(book_file);}
      if (temp_file != NULL) {fclose(temp_file);}
      return -1;
    }
    printf("Digite o ID do livro que você deseja editar: \n");
    printf(">>> ");
    scanf("%hu%*c", &ID);
    if (!(validate_id(&ID, false))) {
      fclose(book_file);
      fclose(temp_file);
      remove("temporary.txt");
      return -1;
    }

    printf("Digite as informações do livro: \n");

    printf("Título: ");
    temporary_book->title = read_string();
    if (temporary_book->title == NULL) {free(temporary_book->title); return 1;}

    printf("Tipo: ");
    temporary_book->type = read_string();
    if (temporary_book->type == NULL) {free(temporary_book->type); return 1;}

    printf("Editora: ");
    temporary_book->publisher = read_string();
    if (temporary_book->publisher == NULL) {free(temporary_book->publisher); return 1;}

    printf("Autor(a): ");
    char *temp_nome = read_string();
    if (temp_nome != NULL) {
      strncpy(temporary_book->author->nome, temp_nome, sizeof(temporary_book->author->nome) - 1);
      temporary_book->author->nome[sizeof(temporary_book->author->nome) - 1] = '\0'; 
      free(temp_nome);
    }
    else {
      return -1;
    }
    printf("ID do(a) autor(a): ");
    scanf("%d", &temporary_book->author->id);
    clear_buffer();
    if (existeAutor(temporary_book->author->id) == 0) {
      printf("Autor não encontrado, deseja cadastrar? (s / n)\n");
      printf(">>> ");
      scanf(" %c", &answer);
      clear_buffer();
      answer = tolower(answer);
      if (answer == 's') {
        cadastrarAutorComId(temporary_book->author->id);
      }
      else if (answer == 'n') {
        return -1;
      }
    }
    else {
      incrementarObrasAutor(temporary_book->author->id);
    }

    printf("Paginas: ");
    scanf("%hu", &temporary_book->pages);
    clear_buffer();

    printf("Ano: ");
    scanf("%hu", &temporary_book->year);
    clear_buffer();

    printf("Quantidade: ");
    scanf("%u", &temporary_book->amount);
    printf("\n");
    clear_buffer();

    char row[256];
    while(fgets(row, sizeof(row), book_file) != NULL) {
      char copy[sizeof(row)];
      strcpy(copy, row);
      char *token = strtok(copy, ";");
      if (token != NULL && (unsigned short int)strtoul(token, NULL, 10) == ID) {
          fprintf(temp_file, "%hu;%s;%s;%s;%s;%d;%hu;%hu;%u\n", ID, temporary_book->title, temporary_book->type, temporary_book->publisher,
            temporary_book->author->nome, temporary_book->author->id, temporary_book->pages, temporary_book->year, temporary_book->amount);}
      else {fputs(row, temp_file);}
    }

    fclose(book_file);
    fclose(temp_file);
    remove("book.txt");
    rename("temporary.txt", "book.txt");
    temp_book_destroy(temporary_book);
    return 0;
}
extern short int delete_book() {
    unsigned short int ID;
    FILE *book_file = fopen("book.txt", "r");
    FILE *temp_file = fopen("temporary.txt", "w");
    if (book_file == NULL || temp_file == NULL) {
      if (book_file != NULL) {fclose(book_file);}
      if (temp_file != NULL) {fclose(temp_file);}
      return -1;
    }

    printf("Digite o ID do livro que deseja deletar: \n");
    printf(">>> ");
    scanf("%hu%*c",&ID);
    if ((!validate_id(&ID, false))) {
      fclose(book_file);
      fclose(temp_file);
      remove("temporary.txt");
      return -1;
    }

    char row[256];
    while (fgets(row, sizeof(row), book_file) != NULL) {
      char copy[sizeof(row)];
      strcpy(copy, row);
      char *token = strtok(copy, ";");
      if (token != NULL && (unsigned short int)strtoul(token, NULL, 10) != ID) {
        fputs(row, temp_file);
      }
    }
    fclose(book_file);
    fclose(temp_file);
    remove("book.txt");
    rename("temporary.txt", "book.txt");
    return 0;
}
extern short int show_book(const unsigned short int *ptr) {
  FILE *book_file = fopen("book.txt", "r");
  if (book_file == NULL) {return -1;}
  char row[256];
  char *elements[9];
  int i = 0;
  char *token;

  printf("\n%-10s||%-31s||%-20s||%-20s||%-30s||%-10s||%-12s||%-10s||%-10s\n","ID","Título","Tipo","Editora","Autor","ID Autor(a)","Qnt.Paginas","Ano","Estoque");
  printf("------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n");

  while(fgets(row, sizeof(row), book_file) != NULL) {
    i = 0;
    char *newline = strchr(row, '\n');
    if (newline != NULL) *newline = '\0';
    if (ptr != NULL)  {
      char row_copy[sizeof(row)];
      strcpy(row_copy, row);
      token = strtok(row_copy, ";");
      if (token == NULL || strtoul(token, NULL, 10) != *ptr) {
        continue;
      }
    }
    token = strtok(row, ";");
    while (token != NULL && i < 9) {
      elements[i] = token;
      i++;
      token = strtok(NULL, ";");
    }
    if (i == 9) {
      printf("%-10hu||%-30s||%-20s||%-20s||%-30s||%-10hu||%-12hu||%-10hu||%-10u\n", (unsigned short int)strtoul(elements[0], NULL, 10), elements[1], elements[2], elements[3], 
      elements[4], (unsigned short int)strtoul(elements[5], NULL, 10),(unsigned short int)strtoul(elements[6], NULL, 10), (unsigned short int)strtoul(elements[7], NULL, 10), (unsigned int)strtoul(elements[8], NULL, 10));
    }
  }
  fclose(book_file);
  return 0;
}
extern short int search_book() {
  unsigned short int ID;
  printf("Digite o ID do livro que deseja buscar: \n");
  printf(">>> ");
  scanf("%hu%*c", &ID);
  if (!(validate_id(&ID, false))) {return -1;}
  show_book(&ID);
  return 0;
}

extern short int lend_book(const unsigned short int ID, const char *mode) {
  FILE *book_file = fopen("book.txt", "r");
  FILE *temp_file = fopen("temporary.txt", "w");
  if (book_file == NULL || temp_file == NULL) {
      if (book_file != NULL) {fclose(book_file);}
      if (temp_file != NULL) {fclose(temp_file);}
      return -1;
  }
  char row[256];
  char *elements[9];
  char *token;
  int i = 0;
  if (get_book_by_id(ID)) {
    while(fgets(row, sizeof(row), book_file) != NULL) {
      i = 0;
      char *newline = strchr(row, '\n');
      if (newline != NULL) {*newline = '\0';}
      char copy[sizeof(row)];
      strcpy(copy, row);
      token = strtok(copy, ";");
      if (token == NULL || (unsigned short int)strtoul(token, NULL, 10) != ID) {
        fprintf(temp_file, "%s\n", row);
        continue;
      }
      token = strtok(row, ";");
      while (token != NULL && i < 9) {
        elements[i] = token;
        i++;
        token = strtok(NULL, ";");
      }
      if (i == 9) {
        unsigned int amount = (unsigned int)strtoul(elements[8], NULL, 10);
        if (strcmp(mode, "-") == 0) {
          if (amount > 0) {amount--;}
        }
        else if (strcmp(mode, "+") == 0) {
          amount++;
        }
        fprintf(temp_file, "%s;%s;%s;%s;%s;%s;%s;%s;%u\n", elements[0], elements[1], elements[2], elements[3], 
          elements[4], elements[5], elements[6], elements[7], amount);
      }
    } 
  }
  else {
    fclose(book_file);
    fclose(temp_file);
    remove("temporary.txt");
    printf("ID do livro não foi encontrado!\n");
    return -1;
  }
  fclose(book_file);
  fclose(temp_file);

  remove("book.txt");
  rename("temporary.txt", "book.txt");
  return 0;
}
extern short int authors_book(int id) {

  FILE *book_file = fopen("book.txt", "r");
  if (book_file == NULL) {return -1;}
  char row[256];
  char *token;
  char *elements_book[9];
  int i = 0;

  // Busca pelos livros do autor

  printf("%-10s||%-31s||%-20s||%-20s||%-30s||%-10s||%-12s||%-10s||%-10s\n","ID","Título","Tipo","Editora","Autor","ID Autor(a)","Qnt.Paginas","Ano","Estoque");
  printf("-------------------------------------------------------------------------------------------------------------------------------------------------------------------\n");

  while (fgets(row, sizeof(row), book_file) != NULL) {
    i = 0;
    char *newline = strchr(row, '\n');
    if (newline != NULL) {*newline = '\0';}
    char copy[sizeof(row)];
    strcpy(copy, row);
    token = strtok(copy, ";");
    while (token != NULL && i < 9) {
      elements_book[i] = token;
      i++;
      token = strtok(NULL, ";");
    }
    if (i == 9) {
      int author_id = (int)strtoul(elements_book[5], NULL, 10);
      if (author_id == id) {
        printf("%-10hu||%-30s||%-20s||%-20s||%-30s||%-10hu||%-12hu||%-10hu||%-10u\n", (unsigned short int)strtoul(elements_book[0], NULL, 10), elements_book[1], elements_book[2], elements_book[3], 
        elements_book[4], (unsigned short int)strtoul(elements_book[5], NULL, 10),(unsigned short int)strtoul(elements_book[6], NULL, 10), (unsigned short int)strtoul(elements_book[7], NULL, 10), (unsigned int)strtoul(elements_book[8], NULL, 10));
    }
  }
}
  fclose(book_file);
  return 0;
}

