#ifndef RELATORIO_H
#define RELATORIO_H

typedef struct {
    int total_livros;
    int total_usuarios;
    int livros_emprestados;
    int livros_disponiveis;
    int total_emprestimos_realizados;
    int livros_em_atraso;
    float total_multas_pendentes;
} Relatorio;

void exibirRelatorio();
void atualizarRelatorio();
void excluirRelatorio();

#endif