#include <stdio.h>
#include <string.h>
#include "autor.h"
#include "book.h"

int obterProximoId()
{
    FILE *arq = fopen(ARQUIVO_AUTOR, "r");
    if (arq == NULL)
        return 1;

    Autor autor;
    int maxId = 0;

    while (fscanf(arq, "%d;%99[^;];%99[^;];%12[^;];%d\n", &autor.id, autor.nome, autor.nacionalidade, autor.ano_nascimento, &autor.total_obras) == 5) {
        if (autor.id > maxId)
            maxId = autor.id;
    }

    fclose(arq);
    return maxId + 1;
}
int existeAutor(int idBusca)
{
    FILE *arq = fopen(ARQUIVO_AUTOR, "r");

    if (arq == NULL)
        return 0;

    Autor autor;

    while (fscanf(arq, "%d;%*[^;];%*[^;];%*[^;];%*d",
                  &autor.id) == 1) {

        if (autor.id == idBusca) {
            fclose(arq);
            return 1;
        }
    }

    fclose(arq);
    return 0;
}
void cadastrarAutorComId(int idSugerido)
{
    Autor autor;
    FILE *arq = fopen(ARQUIVO_AUTOR, "a");
    if (arq == NULL)
    {
        printf("Erro ao abrir o arquivo %s.\n", ARQUIVO_AUTOR);
        return;
    }

    autor.id = (idSugerido > 0) ? idSugerido : obterProximoId();

    printf("\n--- CADASTRANDO AUTOR (ID: %d) ---\n", autor.id);

    printf("DIGITE O NOME DO AUTOR: ");
    scanf(" %99[^\n]", autor.nome);

    printf("DIGITE A NACIONALIDADE: ");
    scanf(" %99[^\n]", autor.nacionalidade);

    printf("DIGITE A DATA DE NASCIMENTO: ");
    scanf(" %12[^\n]", autor.ano_nascimento);

    autor.total_obras = 1;

    fprintf(arq, "%d;%s;%s;%s;%d\n", autor.id, autor.nome, autor.nacionalidade, autor.ano_nascimento, autor.total_obras);
    fclose(arq);

    printf("Autor registrado com sucesso! (ID: %d)\n", autor.id);
}

int incrementarObrasAutor(int idAutor)
{
    if (!existeAutor(idAutor)) {
        return 0;
    }

    FILE *arq = fopen(ARQUIVO_AUTOR, "r");
    FILE *temp = fopen("temp.csv", "w");

    if (arq == NULL || temp == NULL) {
        if (arq) fclose(arq);
        if (temp) fclose(temp);
        return 0;
    }

    Autor autor;
    while (fscanf(arq, "%d;%99[^;];%99[^;];%12[^;];%d\n", &autor.id, autor.nome, autor.nacionalidade, autor.ano_nascimento, &autor.total_obras) == 5) {
        if (autor.id == idAutor) {
            autor.total_obras++;
        }
        fprintf(temp, "%d;%s;%s;%s;%d\n", autor.id, autor.nome, autor.nacionalidade, autor.ano_nascimento, autor.total_obras);
    }

    fclose(arq);
    fclose(temp);

    remove(ARQUIVO_AUTOR);
    rename("temp.csv", ARQUIVO_AUTOR);

    return 1;
}
void listar_autor()
{
    Autor autor;
    int total = 0;
    FILE *arq = fopen(ARQUIVO_AUTOR, "r");

    if (arq == NULL)
    {
        printf("\nNenhum arquivo de autores encontrado ou erro ao abrir.\n");
        return;
    }

    printf("\n%-5s | %-20s | %-20s | %-18s | %s\n", "ID", "NOME", "NACIONALIDADE", "DATA DE NASCIMENTO", "TOTAL DE OBRAS");
    printf("--------------------------------------------------------------------------------------\n");

    while (fscanf(arq, "%d;%99[^;];%99[^;];%12[^;];%d\n", &autor.id, autor.nome, autor.nacionalidade, autor.ano_nascimento, &autor.total_obras) == 5) {
        printf("%-5d | %-20s | %-20s | %-18s | %d\n", autor.id, autor.nome, autor.nacionalidade, autor.ano_nascimento, autor.total_obras);
        total++;
    }

    if (total == 0)
        printf("Nenhum Autor cadastrado.\n");

    fclose(arq);
}

void consultar_autor()
{
    int idBusca;
    Autor autor;
    int encontrado = 0;

    FILE *arq = fopen(ARQUIVO_AUTOR, "r");
    if (arq == NULL)
    {
        printf("\nErro ao abrir o arquivo %s.\n", ARQUIVO_AUTOR);
        return;
    }

    printf("\nDIGITE O ID DO AUTOR A CONSULTAR: ");
    scanf("%d", &idBusca);

    printf("\nDados do autor: \n");

    printf("\n%-5s | %-20s | %-20s | %-18s | %s\n", "ID", "NOME", "NACIONALIDADE", "DATA DE NASCIMENTO", "TOTAL DE OBRAS");
    printf("----------------------------------------------------------------------------------------\n");

    while (fscanf(arq, "%d;%99[^;];%99[^;];%12[^;];%d\n", &autor.id, autor.nome, autor.nacionalidade, autor.ano_nascimento, &autor.total_obras) == 5) {
        if (autor.id == idBusca) {
            printf("%-5d | %-20s | %-20s | %-18s | %d\n", autor.id, autor.nome, autor.nacionalidade, autor.ano_nascimento, autor.total_obras);
            encontrado = 1;
            break;
        }
    }
    printf("\nObras do Autor: \n");
    authors_book(autor.id);

    if (!encontrado)
        printf("Nenhum autor encontrado com o ID %d.\n", idBusca);

    fclose(arq);
}

void remover_autor()
{
    int idBusca;
    Autor autor;
    int encontrado = 0;

    FILE *arq = fopen(ARQUIVO_AUTOR, "r");
    if (arq == NULL)
    {
        printf("\nErro ao abrir o arquivo %s.\n", ARQUIVO_AUTOR);
        return;
    }

    FILE *temp = fopen("temp.csv", "w");
    if (temp == NULL)
    {
        printf("\nErro ao criar arquivo temporario.\n");
        fclose(arq);
        return;
    }

    printf("\nDIGITE O ID DO AUTOR A REMOVER: ");
    scanf("%d", &idBusca);

    while (fscanf(arq, "%d;%99[^;];%99[^;];%12[^;];%d\n", &autor.id, autor.nome, autor.nacionalidade, autor.ano_nascimento, &autor.total_obras) == 5) {
        if (autor.id == idBusca) {
            encontrado = 1;
        } else {
            fprintf(temp, "%d;%s;%s;%s;%d\n", autor.id, autor.nome, autor.nacionalidade, autor.ano_nascimento, autor.total_obras);
        }
    }

    fclose(arq);
    fclose(temp);

    remove(ARQUIVO_AUTOR);
    rename("temp.csv", ARQUIVO_AUTOR);

    if (encontrado)
        printf("Autor de ID %d removido com sucesso!\n", idBusca);
    else
        printf("Autor de ID %d nao encontrado.\n", idBusca);
}

void atualizar_autor()
{
    int idBusca;
    Autor autor;
    int encontrado = 0;

    FILE *arq = fopen(ARQUIVO_AUTOR, "r");
    if (arq == NULL)
    {
        printf("\nErro ao abrir o arquivo %s.\n", ARQUIVO_AUTOR);
        return;
    }

    FILE *temp = fopen("temp.csv", "w");
    if (temp == NULL)
    {
        printf("\nErro ao criar arquivo temporario.\n");
        fclose(arq);
        return;
    }

    printf("\nDIGITE O ID DO AUTOR A ATUALIZAR: ");
    scanf("%d", &idBusca);

    while (fscanf(arq, "%d;%99[^;];%99[^;];%12[^;];%d\n", &autor.id, autor.nome, autor.nacionalidade, autor.ano_nascimento, &autor.total_obras) == 5) {
        if (autor.id == idBusca) {
            encontrado = 1;
            printf("\n--- NOVOS DADOS PARA O AUTOR ID %d (%s) ---\n", autor.id, autor.nome);

            printf("DIGITE O NOVO NOME DO AUTOR: ");
            scanf(" %99[^\n]", autor.nome);

            printf("DIGITE A NOVA NACIONALIDADE: ");
            scanf(" %99[^\n]", autor.nacionalidade);

            printf("DIGITE A NOVA DATA DE NASCIMENTO: ");
            scanf(" %12[^\n]", autor.ano_nascimento);

            printf("DIGITE O NOVO TOTAL DE OBRAS: ");
            scanf("%d", &autor.total_obras);
        }
        fprintf(temp, "%d;%s;%s;%s;%d\n", autor.id, autor.nome, autor.nacionalidade, autor.ano_nascimento, autor.total_obras);
    }

    fclose(arq);
    fclose(temp);

    remove(ARQUIVO_AUTOR);
    rename("temp.csv", ARQUIVO_AUTOR);

    if (encontrado)
        printf("Autor ID %d atualizado com sucesso!\n", idBusca);
    else
        printf("Autor ID %d nao encontrado.\n", idBusca);
}

int adicionar_autor() {
    Autor autor;
            FILE *arq = fopen(ARQUIVO_AUTOR, "a");
            if (arq == NULL) {
                printf("Erro ao abrir o arquivo %s.\n", ARQUIVO_AUTOR);
                return 1;
            }

            autor.id = obterProximoId();

            printf("\n--- CADASTRANDO AUTOR (ID: %d) ---\n", autor.id);

            printf("DIGITE O NOME DO AUTOR: ");
            scanf(" %99[^\n]", autor.nome);

            printf("DIGITE A NACIONALIDADE: ");
            scanf(" %99[^\n]", autor.nacionalidade);

            printf("DIGITE A DATA DE NASCIMENTO: ");
            scanf(" %12[^\n]", autor.ano_nascimento);

            printf("DIGITE O TOTAL DE OBRAS: ");
            scanf("%d", &autor.total_obras);

            fprintf(arq, "%d;%s;%s;%s;%d\n", autor.id, autor.nome, autor.nacionalidade, autor.ano_nascimento, autor.total_obras);
            fclose(arq);

            printf("Autor registrado com sucesso! (ID: %d)\n", autor.id);
            return 0;
}