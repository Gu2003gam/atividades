#include <stdio.h> 
#include <string.h> 
#include <stdlib.h> 
#include <ctype.h> 
#include <time.h>
#include "emp.h"

// Definição das variáveis globais
Emprestimo loan[MAX];  
struct tm data = {0};
char end, finish;
char NR_busca[20], ID_busca[ARRAY];
char leitura[256];
char nr_temp[20], titulo_temp[ARRAY];
unsigned int idade_temp, dia_temp, mes_temp, ano_temp, diatm, mestm, anotm;  
char id_temp[ARRAY]; 
short int achou = 0; 
short int opcao;
int qtd_emprestimo = 0;
int i;
int contador_emp;

void limpar_buffer(void){
    int c;
    while((c = getchar()) != '\n' && c != EOF){}
}

void limpar_tela(void){
    printf("\033[2J\033[H");
}

void garantir_arquivo(void) {
    FILE *arc = fopen(LIST, "r");

    if (arc == NULL) {
        arc = fopen(LIST, "w");

        if (arc == NULL) {
            printf("Erro ao criar arquivo!\n");
            return; 
        }

        fprintf(arc, "User;ID do livro;titulo;idade\n");
    }

    fclose(arc);
}   

int validador_emprestimo(void){
      qtd_emprestimo = 0; // Reinicia a contagem para evitar acúmulo incorreto
      FILE *arq = fopen(LIST, "r"); 
          if (arq == NULL){
            printf("Erro, arquivo nao encontrado %s\n", LIST);
            return -1;
          }

          fgets(leitura, sizeof(leitura), arq); 

          while(fscanf(arq, " %19[^;];%19[^;];%99[^;];%u;%02u/%02u/%u;%02u/%02u/%u\n", nr_temp, id_temp, titulo_temp, &idade_temp,
                                                                  &dia_temp, &mes_temp, &ano_temp, &diatm, &mestm, &anotm) == 10){
            
             if (strcmp(nr_temp, loan[i].NR) == 0){
                qtd_emprestimo++;

                printf("\nQuantidade de emprestimo: %d\n", qtd_emprestimo);
                printf("\nID do livro: %s\n", id_temp);
                printf("\nTitulo: %s\n", titulo_temp);
                printf("Data de emprestimo: %02u/%02u/%u\n", dia_temp, mes_temp, ano_temp);
                printf("Data de devolucao: %02u/%02u/%u\n", diatm, mestm, anotm); 
                printf("\n\n");
             }
          }
         fclose(arq);

         if(qtd_emprestimo >= 3){
          printf("\nUsuario atingiu o limite de %d emprestimos\n", qtd_emprestimo);
          return qtd_emprestimo;
         }
         return qtd_emprestimo;
}

void novo_emprestimo(void) {
      garantir_arquivo(); 
      limpar_tela();
      printf("Criar novo cadastro.\n"); 

       FILE *arc = fopen(LIST, "a"); 
          if(arc == NULL){
            printf("Erro ao abrir o arquivo %s\n", LIST); 
            return;
          }

     for ( i = 0; i < MAX; i++){
         printf("Numero de registro:\n");
           fgets(loan[i].NR, sizeof(loan[i].NR), stdin);
              loan[i].NR[strcspn(loan[i].NR, "\n")] = '\0'; 
             
              contador_emp = validador_emprestimo();

              if (contador_emp == -1){
                fclose(arc);
                return;
              }

              if (qtd_emprestimo >= 3){
                printf("\nLimite de emprestimos atingido!\n");
                break;
               }

         printf("ID do livro:\n");
            fgets(loan[i].id_livro, sizeof(loan[i].id_livro), stdin);
             loan[i].id_livro[strcspn(loan[i].id_livro, "\n")] = '\0';

         printf("Titulo do livro:\n"); 
          fgets(loan[i].titulo_livro, sizeof(loan[i].titulo_livro), stdin); 
            loan[i].titulo_livro[strcspn(loan[i].titulo_livro, "\n")] = '\0'; 

         printf("Idade:\n"); 
          scanf("%u", &loan[i].idade); 
           limpar_buffer(); 
          
          //calculando data de entrega//
          memset(&data, 0, sizeof(data)); 
          printf("Data de emprestimo(DD MM AAAA)\n"); 
           scanf(" %u %u %u", &loan[i].dia, &loan[i].mes, &loan[i].ano);
            limpar_buffer();

            data.tm_mday = loan[i].dia;
            data.tm_mon = loan[i].mes - 1;
            data.tm_year = loan[i].ano - 1900; 

            data.tm_mday += 30;

            mktime (&data);
             
          //*****Salvando dados*****//
         fprintf(arc, "%s;%s;%s;%u;%02u/%02u/%u;%02u/%02u/%u\n", loan[i].NR, loan[i].id_livro, loan[i].titulo_livro,
                        loan[i].idade, loan[i].dia, loan[i].mes, loan[i].ano, data.tm_mday, data.tm_mon + 1, data.tm_year + 1900);
         fflush(arc); 
          
        //****Deseja continuar****//
        printf("Deseja fazer mais um emprestimo?\n"); 
         scanf(" %c", &end); 
            getchar();

            limpar_tela();
         finish = tolower(end);   
           if (finish == 'n'){
              break; 
           } 
     }
      
     fclose(arc); 
     printf("Cadastro realizado com sucesso!\n");
}

void listar_ou_consultar_emprestimos(void) {
        limpar_tela();
        int giros = 0;
        printf("1-Lista de emprestimos.\n2-Consultar emprestimo.\n");
         scanf(" %hd", &opcao); 
          limpar_buffer(); 
          
       switch(opcao){
        case 1: {
           limpar_tela();
           FILE *arq = fopen(LIST, "r"); 
            if(arq == NULL){
              printf("Erro ao abrir o arquivo!\n");
              return;
            }

          fgets(leitura, sizeof(leitura), arq);
            printf("\n%-20s||%-20s||%-35s||%-15s||%-25s||%-25s\n", "NR", "ID do livro", "Titulo do livro", "Idade", "Data de Emprestimo", "Data de devolucao");
            printf("--------------------------------------------------------------------------------------------------------------------------------------------------\n");

             while(fscanf(arq, " %19[^;];%19[^;];%99[^;];%u;%02u/%02u/%u;%02u/%02u/%u\n", nr_temp, id_temp, titulo_temp, &idade_temp, &dia_temp, &mes_temp, &ano_temp, &diatm, &mestm, &anotm) == 10) {
              printf("%-19s  %-19s %-35s  %5u  %15u/%u/%u  %15u/%u/%u\n", nr_temp, id_temp, titulo_temp, idade_temp, dia_temp, mes_temp, ano_temp, diatm, mestm, anotm);
              giros++;
             }
            printf("----------------------------------------------------------------------------------------------------------------------------------------------------\n");
             if (giros == 0){
              printf("Nenhum emprestimo encontrado.\n");
              fclose(arq);
              return;
             }
             fclose(arq);
             break;
            }

        case 2: {
          limpar_tela();
          printf("Consultar emprestimo.\n");

          FILE *arq = fopen(LIST, "r"); 
          if (arq == NULL){
            printf("Erro, arquivo nao encontrado %s\n", LIST);
            return;
          }

          printf("Numero de registro:\n");
           fgets(NR_busca, sizeof(NR_busca), stdin);
            NR_busca[strcspn(NR_busca, "\n" "\r")] = '\0'; 
            
          fgets(leitura, sizeof(leitura), arq); 

          achou = 0;
          while(fscanf(arq, " %19[^;];%19[^;];%99[^;];%u;%02u/%02u/%u;%02u/%02u/%u\n", nr_temp, id_temp, titulo_temp, &idade_temp, &dia_temp, &mes_temp, &ano_temp, &diatm, &mestm, &anotm) == 10){
                      if (strcmp(nr_temp, NR_busca) == 0){
                        printf("\nContrato encontrado:\n");
                        printf("Numero de registro: [%s]\n", nr_temp);
                        printf("ID do livro:    %s\n", id_temp);
                        printf("Titulo do livro:    %s\n", titulo_temp);
                        printf("Idade:    %u\n", idade_temp); 
                        printf("Data do emprestimo: %02u/%02u/%u\n", dia_temp, mes_temp, ano_temp);
                        printf("Data de devolucao: %02u/%02u/%u\n", diatm, mestm, anotm);
                        achou = 1; 
                        break; 
                      }
          }
           
          if (!achou){
            printf("Aluno nao encontrado!\n");
          }
          fclose(arq); 
        } 
        break;

        default: 
         printf("Opcao invalida\n");
       }   
}

void atualizar_emprestimo(void) {
    limpar_tela();
    short int atualizado = 0;   
    
    FILE *arq = fopen(LIST, "r"); 
    FILE *temp = fopen(ARQUITEMP, "w");

     if(arq == NULL || temp == NULL){
      printf("Erro ao abrir o arquivo.\n"); 
      if (arq != NULL){fclose(arq);}
      if (temp != NULL){fclose(temp);}
      return;
     }

     printf("Qual o Numero de registro:\n"); 
      fgets(NR_busca, sizeof(NR_busca), stdin);
       NR_busca[strcspn(NR_busca, "\n")] = '\0'; 

     printf("Livro que deseja atualizar:\n");
      fgets(ID_busca, sizeof(ID_busca), stdin);
        ID_busca[strcspn(ID_busca, "\n")] = '\0';

         fgets(leitura, sizeof(leitura), arq); 
         fputs(leitura, temp); 

      while(fscanf(arq, " %19[^;];%19[^;];%99[^;];%u;%02u/%02u/%u;%02u/%02u/%u\n", nr_temp, id_temp, titulo_temp, &idade_temp, &dia_temp, &mes_temp, &ano_temp, &diatm, &mestm, &anotm) == 10){
                if(strcmp(nr_temp, NR_busca) == 0 && strcmp(id_temp, ID_busca) == 0){
                  printf("Cadastro encontrado %s\n\n\n", nr_temp);
                            
                       printf("Novo Id do livro:\n");
                         scanf(" %s", id_temp); 
                          limpar_buffer();

                        printf("Titulo do Livro:\n");
                         fgets(titulo_temp, sizeof(titulo_temp), stdin);
                           titulo_temp[strcspn(titulo_temp, "\n")] = '\0';
                           
                          printf("Nova idade:\n");
                           scanf(" %u", &idade_temp); 
                            limpar_buffer(); 

                        memset(&data, 0, sizeof(data));

                         printf("Data de emprestimo(DD MM AAAA)\n"); 
                          scanf(" %u %u %u", &dia_temp, &mes_temp, &ano_temp);
                            limpar_buffer();
                            
                            data.tm_mday = dia_temp;
                            data.tm_mon = mes_temp - 1;
                            data.tm_year = ano_temp - 1900; 

                            data.tm_mday += 30;

                            mktime (&data); 
                            
                   fprintf(temp,"%s;%s;%s;%u;%02u/%02u/%u;%02u/%02u/%u\n", nr_temp, id_temp, titulo_temp, idade_temp,
                                               dia_temp, mes_temp, ano_temp, data.tm_mday, data.tm_mon + 1, data.tm_year + 1900);
                   atualizado = 1; 
                } else {
                   fprintf(temp,"%s;%s;%s;%u;%02u/%02u/%u;%02u/%02u/%u\n", nr_temp, id_temp, titulo_temp, idade_temp,
                                               dia_temp, mes_temp, ano_temp, diatm, mestm, anotm);
                 }
       }
        fclose(arq);
        fclose(temp);

         if(atualizado == 1){
           remove(LIST);
           rename(ARQUITEMP, LIST);
           printf("Cadastro atualizado com sucesso.\n");
         } else {
            remove(ARQUITEMP);
            printf("NR: %s nao encontrado \n", NR_busca);
         }
}

void excluir_emprestimo(void) {
     limpar_tela();
     short int excluido = 0; 

     FILE *arq = fopen(LIST, "r");
     FILE *temp = fopen(ARQUITEMP, "w"); 
       if(arq == NULL || temp == NULL){
            printf("Erro ao abrir o arquivo.\n"); 
         if (arq != NULL){fclose(arq);}
         if (temp != NULL){fclose(temp);}
         return;
        } 

        printf("Qual o Numero de registro:\n"); 
          fgets(NR_busca, sizeof(NR_busca), stdin);
            NR_busca[strcspn(NR_busca, "\n")] = '\0'; 

         printf("Qual o id do livro:\n");
           fgets(ID_busca, sizeof(ID_busca), stdin);
            ID_busca[strcspn(ID_busca, "\n")] = '\0';   

        fgets(leitura, sizeof(leitura), arq); 
        fputs(leitura, temp); 
       
     while(fscanf(arq, " %19[^;];%19[^;];%99[^;];%u;%02u/%02u/%u;%02u/%02u/%u\n", nr_temp, id_temp, titulo_temp, &idade_temp, &dia_temp, &mes_temp, &ano_temp, &diatm, &mestm, &anotm) == 10){
           if(strcmp(nr_temp, NR_busca) == 0 && strcmp(id_temp, ID_busca) == 0){
               excluido = 1; 
           } else {
           fprintf(temp,"%s;%s;%s;%u;%02u/%02u/%u;%02u/%02u/%u\n", nr_temp, id_temp, titulo_temp, idade_temp,
                                               dia_temp, mes_temp, ano_temp, diatm, mestm, anotm);
           }
     }      

        fclose(arq);
        fclose(temp);

        if (excluido == 1){
          remove(LIST);
          rename(ARQUITEMP, LIST);
          printf("Emprestimo excluido com sucesso.\n"); 
        } else {
          remove(ARQUITEMP);
          printf("Numero de registro %s nao encontrado.\n", NR_busca); 
        }
}