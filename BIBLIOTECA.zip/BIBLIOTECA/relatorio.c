#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "usuario.h"
#include "emp.h"

typedef struct {
    int total_livros;
    int total_usuarios;
    int livros_emprestados;
    int livros_disponiveis;
    int total_emprestimos_realizados;
    int livros_em_atraso;
    float total_multas_pendentes;
} Relatorio;

int relatorio_contar_livro() {
    FILE *arquivo = fopen("book.txt", "r");

    if(arquivo == NULL) {
        return 0;
    }

    char linha[200];
    int total = 0;

    if(fgets(linha, sizeof(linha), arquivo) != NULL) {
        while(fgets(linha, sizeof(linha), arquivo) != NULL) {
            total++;
        }
    }

    fclose(arquivo);
    return total;
}

int relatorio_contar_usuario(void) {
    FILE *arquivo = fopen(ARQUIVO, "r");

    if(arquivo == NULL) {
        return 0;
    }
    char linha[200];
    int total = 0;

    if(fgets(linha, sizeof(linha), arquivo) != NULL) {
        while(fgets(linha, sizeof(linha), arquivo) != NULL) {
            if(strlen(linha) > 1) {
                total++; 
            }
        }
    }

    fclose(arquivo);
    return total;
}

int relatorio_contar_emprestimos(int *emprestados_atualmente) {
    FILE *arquivo = fopen(LIST, "r");
    if(arquivo == NULL) {
        if(emprestados_atualmente) *emprestados_atualmente = 0;
        return 0;
    }
    char linha[256];
    int total_realizados = 0;
    int ativos = 0;

    if(fgets(linha, sizeof(linha), arquivo) != NULL) {
        while(fgets(linha, sizeof(linha), arquivo) != NULL) {
            if(strlen(linha) > 1) {
                total_realizados++;
                ativos++;
            }
        }
    }
    fclose(arquivo);
    if(emprestados_atualmente) *emprestados_atualmente = ativos;
    return total_realizados;
}

void exibirRelatorio() {
    FILE *arquivo = fopen("relatorio.txt", "r");

    if(arquivo == NULL) {
        printf("Houve um erro durante a abertura do arquivo!\n");
        return;
    }

    char cabecalho[1024];
    if (fgets(cabecalho, sizeof(cabecalho), arquivo) == NULL) {
        printf("\nArquivo vazio ou erro ao ler cabeçalho!\n");
        fclose(arquivo);
        return;
    }

    Relatorio r;
    printf("\nDADOS DOS RELATÓRIOS:\n");

    while(fscanf(arquivo, "%d, %d, %d, %d, %d, %d, %f",
        &r.total_livros,
        &r.total_usuarios,
        &r.livros_emprestados,
        &r.livros_disponiveis,
        &r.total_emprestimos_realizados,
        &r.livros_em_atraso,
        &r.total_multas_pendentes
    ) == 7) {
        printf(
            "Total de Livros: %d\n"
            "Total de Usuários: %d\n"
            "Livros emprestados: %d\n"
            "Livros disponíveis: %d\n"
            "Total de empréstimos realizados: %d\n"
            "Livros em atraso: %d\n"
            "Total de multas pendentes: %.1f\n\n", 
            r.total_livros, r.total_usuarios, r.livros_emprestados, 
            r.livros_disponiveis, r.total_emprestimos_realizados, 
            r.livros_em_atraso, r.total_multas_pendentes
        );
    }

    fclose(arquivo);
}

void atualizarRelatorio() {
    Relatorio r;

        r.total_usuarios = relatorio_contar_usuario();
        r.total_livros = relatorio_contar_livro();

        int emprestados = 0;
        r.total_emprestimos_realizados = relatorio_contar_emprestimos(&emprestados);
        r.livros_emprestados = emprestados;
        if(r.livros_emprestados > r.total_livros) {
            r.livros_disponiveis = 0;
        } else {
            r.livros_disponiveis = r.total_livros - r.livros_emprestados;
        }

        r.livros_em_atraso = 0;
        r.total_multas_pendentes = 0.0f;
    FILE *arquivo = fopen("relatorio.txt", "a");

    if(arquivo == NULL) {
        printf("\nHouve um erro durante a abertura do arquivo!\n");
        return;
    }

    fprintf(arquivo, "%d, %d, %d, %d, %d, %d, %.2f\n",
        r.total_livros,
        r.total_usuarios,
        r.livros_emprestados,
        r.livros_disponiveis,
        r.total_emprestimos_realizados,
        r.livros_em_atraso,
        r.total_multas_pendentes
    );

    fclose(arquivo);
    printf("\nOs dados do relatório foram atualizados com sucesso!\n");
}

void excluirRelatorio() {
    FILE *arquivo = fopen("relatorio.txt", "w");

    if(arquivo == NULL) {
        printf("\nHouve um erro ao tentar limpar o arquivo!\n");
        return;
    }

    fprintf(arquivo, "total_livros, total_usuarios, livros_emprestados, livros_disponiveis, total_emprestimos_realizados, livros_em_atraso, total_multas_pendentes\n");

    fclose(arquivo);
    printf("\nTodos os registros do relatório foram excluídos com sucesso!\n");
}