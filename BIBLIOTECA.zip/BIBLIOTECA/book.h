#ifndef BOOK_H
#define BOOK_H

short int add_book();
short int edit_book();
short int delete_book();
short int show_book(const unsigned short int *ptr);
short int search_book();
short int lend_book(const unsigned short int ID, const char *mode);
short int authors_book(int id);

#endif
