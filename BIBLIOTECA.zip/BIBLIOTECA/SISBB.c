#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "relatorio.h"
#include "autor.h"
#include "usuario.h"
#include "book.h"
#include "emp.h"

int main() {
    int opcaoMenu = -1;

    while(opcaoMenu != 0) {
        int opcaoSubmenu = 0;
        
        printf(
            "\n+++++++++++++++++++++++++++++++++++++++\n"
            "SISBB - SISTEMA DE GESTÃO DE BIBLIOTECAS\n"
            "+++++++++++++++++++++++++++++++++++++++\n\n"
            "1 - Gestão de Livros\n"
            "2 - Gestão de Autores\n"
            "3 - Gestão de Usuários\n"
            "4 - Gestão de Empréstimos\n"
            "5 - Relatórios\n"
            "0 - Sair\n\n"
            "Escolha uma opção: "
        );

        if (scanf("%d", &opcaoMenu) != 1) {
            printf("\n[Erro] Entrada inválida! Por favor, digite um número.\n");
            while (getchar() != '\n');
            continue;
        }
        
        while (getchar() != '\n');

        if (opcaoMenu == 0) {
            printf("\nFechando o sistema...\n");
            break;
        }

        switch(opcaoMenu) {
            case 1:
                do {
                    printf(
                        "\n--- GESTÃO DE LIVROS ---\n"
                        "1 - Adicionar Livro\n"
                        "2 - Exibir Livros\n"
                        "3 - Atualizar Livro\n"
                        "4 - Excluir Livro\n"
                        "5 - Buscar Livro por ID\n"
                        "0 - Voltar ao Menu Principal\n"
                        "Escolha uma opção: "
                    );
                    scanf("%d", &opcaoSubmenu);
                    while (getchar() != '\n');

                    switch(opcaoSubmenu) {
                        case 1: add_book(); break;
                        case 2: show_book(NULL); break;
                        case 3: edit_book(); break;
                        case 4: delete_book(); break;
                        case 5: search_book(); break;
                        case 0: break;
                        default: printf("\nOpção inválida!\n"); break;
                    }
                } while(opcaoSubmenu != 0);
                break;

            case 2:
                do {
                    printf(
                        "\n--- GESTÃO DE AUTORES ---\n"
                        "1 - Adicionar Autor\n"
                        "2 - Exibir Autor\n"
                        "3 - Atualizar Autor\n"
                        "4 - Excluir Autor\n"
                        "5 - Consultar Autor\n"
                        "0 - Voltar ao Menu Principal\n"
                        "Escolha uma opção: "
                    ); 
                    scanf("%d", &opcaoSubmenu);
                    while (getchar() != '\n');

                    switch(opcaoSubmenu) {
                        case 1: adicionar_autor(); break;
                        case 2: listar_autor(); break;
                        case 3: atualizar_autor(); break;
                        case 4: remover_autor(); break;
                        case 5: consultar_autor(); break;
                        case 0: break;
                        default: printf("\nOpção inválida!\n"); break;
                    }
                } while(opcaoSubmenu != 0);
                break;

            case 3:
                do {
                    printf(
                        "\n--- GESTÃO DE USUÁRIOS ---\n"
                        "1 - Cadastrar Usuários\n"
                        "2 - Listar Usuários\n"
                        "3 - Excluir Usuários\n"
                        "4 - Atualizar cadastro de Usuários\n"
                        "0 - Voltar ao Menu Principal\n"
                        "Escolha uma opção: "
                    );
                    scanf("%d", &opcaoSubmenu);
                    while (getchar() != '\n');

                    switch(opcaoSubmenu) {
                        case 1: usuario_cadastrar(); break;
                        case 2: usuario_listar(); break;
                        case 3: usuario_excluir(); break;
                        case 4: usuario_atualizar(); break;
                        case 0: break;
                        default: printf("\nOpção inválida!\n"); break;
                    }
                } while(opcaoSubmenu != 0);
                break;

            case 4:
                do {
                    printf("\n--- MENU DE EMPRÉSTIMOS ---\n");
                    printf("1 - Novo emprestimo\n");
                    printf("2 - Lista / Consultar emprestimos\n");
                    printf("3 - Atualizar emprestimo\n");
                    printf("4 - Excluir registro de emprestimo\n");
                    printf("5 - Fechar\n");
                    printf("Escolha uma opcao: ");
                    
                    scanf("%d", &opcaoSubmenu);
                    while (getchar() != '\n');

                    switch (opcaoSubmenu) {
                        case 1:
                            novo_emprestimo();
                            break;
                        case 2:
                            listar_ou_consultar_emprestimos();
                            break;
                        case 3:
                            atualizar_emprestimo();
                            break;
                        case 4:
                            excluir_emprestimo();
                            break;
                        case 5:
                            limpar_tela();
                            printf("Fechando Programa...\n");
                            opcaoSubmenu = 0;
                            break;
                        default:
                            printf("Opcao invalida, escolha novamente.\n");
                    }
                } while(opcaoSubmenu != 0);
                break;

            case 5:
                do {
                    printf(
                        "\n--- GESTÃO DE RELATÓRIO ---\n"
                        "1 - Exibir Relatório\n"
                        "2 - Atualizar Relatório\n"
                        "3 - Excluir Relatório\n"
                        "0 - Voltar ao Menu Principal\n"
                        "Escolha uma opção: "
                    );
                    scanf("%d", &opcaoSubmenu);
                    while (getchar() != '\n');

                    switch(opcaoSubmenu) {
                        case 1: exibirRelatorio(); break;
                        case 2: atualizarRelatorio(); break;
                        case 3: excluirRelatorio(); break;
                        case 0: break;
                        default: printf("\nOpção inválida!\n"); break;
                    }
                } while(opcaoSubmenu != 0);
                break;

            default:
                printf("\nOpção inválida no menu principal!\n");
                break;
        }
    }
    return 0;
}