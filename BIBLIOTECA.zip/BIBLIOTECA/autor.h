#ifndef AUTOR_H
#define AUTOR_H
#define ARQUIVO_AUTOR "autor.csv"
#define MAX_NOME 100
#define TAM_NACIONALIDADE 100
#define TAM_DATA 13

typedef struct {
    int id;
    char nome[MAX_NOME];
    char nacionalidade[TAM_NACIONALIDADE];
    char ano_nascimento[TAM_DATA];
    int total_obras;
} Autor;

int obterProximoId();
void listar_autor();
void consultar_autor();
void remover_autor();
void atualizar_autor();
int adicionar_autor();
int existeAutor(int idBusca);
void cadastrarAutorComId(int idSugerido);
int incrementarObrasAutor(int idAutor);
#endif