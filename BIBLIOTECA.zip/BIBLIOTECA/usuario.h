#ifndef USUARIO_H
#define USUARIO_H

#define ARQUIVO "usuarios.csv"
#define ARQ_TEMP "temp.csv"
#define MAX_NOME 100
#define MAX_CARGO 100

typedef struct {
    int codigo;
    char nome[MAX_NOME];
    int idade;
    char cargo[MAX_CARGO];
} Usuario;

// Protótipos das funções com nomes específicos
void usuario_limpar_tela(void);
void usuario_limpar_buffer(void);
void usuario_garantir_arquivo(void);
void usuario_cadastrar(void);
void usuario_consultar(void);
void usuario_listar(void);
void usuario_excluir(void);
void usuario_atualizar(void);

#endif