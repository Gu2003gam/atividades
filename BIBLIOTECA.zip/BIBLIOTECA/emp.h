#ifndef EMP_H
#define EMP_H

#define MAX 3
#define ARRAY 100
#define LIST "list.txt"
#define ARQUITEMP "temp.txt"
#define USER "usuarios.txt"

typedef struct {
     unsigned int dia, mes, ano; 
     unsigned int idade; 
     char NR[20];
     char id_livro[20];
     char titulo_livro[ARRAY]; 
} Emprestimo;

// Variáveis globais externas utilizadas pelas funções
extern Emprestimo loan[MAX];
extern struct tm data;
extern char end, finish;
extern char NR_busca[20], ID_busca[ARRAY];
extern char leitura[256];
extern char nr_temp[20], titulo_temp[ARRAY];
extern unsigned int idade_temp, dia_temp, mes_temp, ano_temp, diatm, mestm, anotm;  
extern char id_temp[ARRAY]; 
extern short int achou; 
extern short int opcao;
extern int qtd_emprestimo;
extern int contador_emp;

void limpar_buffer(void);
void limpar_tela(void);
void garantir_arquivo(void);
int validador_emprestimo(void);

void novo_emprestimo(void);
void listar_ou_consultar_emprestimos(void);
void atualizar_emprestimo(void);
void excluir_emprestimo(void);

#endif